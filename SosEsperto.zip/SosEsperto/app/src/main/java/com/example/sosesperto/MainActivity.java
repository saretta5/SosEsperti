package com.example.sosesperto;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void registratiBtn_onClick(View view){
        Intent intento = new Intent(this, Registrazione.class);
        startActivity(intento);
    }

    public void accediBtn_onClick(View view){
        Intent intento = new Intent(this, Home.class);
        startActivity(intento);
    }
    public void accediDopoBtn_onClick(View view){
        Intent intento = new Intent(this, Home.class);
        startActivity(intento);
    }
    public void passdimLbl_onClick(View view){
        Intent intento = new Intent(this, PasswordDimenticata.class);
        startActivity(intento);
    }
}