package com.example.sosesperto;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class NuovoAnnuncio extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nuovo_annuncio);

    }
}

